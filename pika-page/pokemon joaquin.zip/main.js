const pokemonImage = document.getElementById("js--pokeImage")
const catchButton = document.getElementById("js--catchbutton")
const pokemonText = document.getElementById("js--pokeText")
let running = false
let randomNumber = Math.floor(Math.random() * 1009 + 1);

let pokemon = fetch("https://pokeapi.co/api/v2/pokemon/" + randomNumber)
        .then(function (response) {
                return response.json();
        })
        .then(function (realData) {
                pokemonImage.src = realData.sprites.front_default
                pokemonImage.text = realData.name
                pokemonName = realData.name
                pokemonImageshiny = realData.sprites.front_shiny

                pokemonName = pokemonName.charAt(0).toUpperCase() + pokemonName.slice(1);
                pokemonText.innerText = "A wild " + pokemonName + " appeared"
                const shinychance = Math.floor(Math.random() * 9 + 1);

                if (shinychance === 1) {
                        pokemonImage.src = pokemonImageshiny
                        pokemonText.innerText = "A SHINY " + pokemonName + " appeared"
                }
        })

catchButton.onclick = function () {

        if (running === false) {
                let catchNumber = Math.floor(Math.random() * 2);
                if (catchNumber === 0) {
                        pokemonText.innerText = pokemonName + " fled"

                }
                else {
                        pokemonText.innerText = pokemonName + " was caught"

                }
                running = true
        }

};


const serie = document.getElementById("js--title")
const text = document.getElementById("js--text")
const randomNumber2 = Math.random();
const result = randomNumber2 < 0.5 ? 495 : 1505;

let film = fetch("https://api.tvmaze.com/shows/" + result)
        .then(function (response) {
                return response.json();
        })
        .then(function (realData) {
                serie.innerText = realData.name
                text.innerHTML = realData.summary
        })

const naam = document.getElementById("js--name")

const input = document.getElementById("js--input")

input.onkeyup = function (event) {
        if (event.keyCode === 13) {
                let name = input.value

                let age = fetch("https://api.agify.io?name=" + name)
                        .then(function (response) {
                                return response.json();
                        })
                        .then(function (data) {
                                naam.innerText = data.age;
                                input.style.display = "none";
                        });
        }
}